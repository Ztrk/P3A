program run for an hour (fast partition limit ~ 1:00:00 h:mm:ss)

output file system ((+port_name) -> instances -> bap algorithms) will likely be rolled back on January 21st so that it does not appear in .err files (p3amulti.err etc.)

output stream
10p10inst: p3amulti.out empty (output file - evaluated_berths_info.txt)
50p50inst: output file - p3amulti.out

local_search.log and file with execution times are empty (are not included in both folders)
