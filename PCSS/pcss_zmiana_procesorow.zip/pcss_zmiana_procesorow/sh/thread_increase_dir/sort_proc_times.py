import sys

def sorf_from_file(filename,outfilename):
    with open(filename) as inf:
        data = []
        last_proc=0
        next_proc=0
        processor_group = []
        processor_group_list = []
        for line in inf:
            #print(line)
            line = line.split()
            if (line[0]=="process" and line[1]=="amount"):
                if (len(processor_group)>0):
                    processor_group_list.append(processor_group)
                processor_group = []
            processor_group.append(line)
        processor_group_list.append(processor_group)
    
    procesors_and_times = []
    proc_time = []
    for group in processor_group_list:
        print("grupa ",processor_group_list.index(group))
        mean=0
        for line in group:
            if (line[0]=="process" and line[1]=="amount"):
                proc_time.append(line[2])
            print(line)

    #data.sort()

filename=sys.argv[1]

#outfilename=sys.argv[2]
outfilename="xdd"
if (len(filename)==0 or len(outfilename)==0): sys.exit("podaj plik wejściowy lub wyjściowy")

print(filename)
sorf_from_file(filename,outfilename)