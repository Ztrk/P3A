#!/bin/bash

mkdir thread_changing

module load mpich

time_array=()

#echo "aasasas: ${time_array[0]}"

Process_max=8

filename='./thread_changing/threads_times_'$Process_max
echo $filename
touch $filename

for i in $(seq 1 $Process_max);
do 
	echo "process number: $i";
	STARTTIME=$(date +%s)
	mpirun -n $i ./p3a
	ENDTIME=$(date +%s)
	time=$[$ENDTIME - $STARTTIME]
	time_array[$i-1]=$time
	echo "It takes ${time_array[$i-1]}"
done



echo "threads times" >> $filename
for i in $(seq 0 $[$Process_max-1]);
do 
	echo "i: $i";
	echo "$[$i+1] ${time_array[$i]}" >> $filename;
done

echo "all times: ${time_array[@]}"


