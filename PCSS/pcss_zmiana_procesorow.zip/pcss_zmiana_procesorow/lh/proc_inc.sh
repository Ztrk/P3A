#!/bin/bash

#SBATCH --job-name=lh50
#SBATCH --output=thread_increase_dir/sd_si.out
#SBATCH --error=thread_increase_dir/sd_si.err
#SBATCH --time=5-0:00:00
#SBATCH --partition=standard
#SBATCH --ntasks=50

module load mpich

Process_min=$1
Process_max=$2
Inst_min=50


mkdir "thread_increase_dir"

for ((inst = $Inst_min; inst>=$Inst_min; inst = inst - 20))
do
    echo "rozmiar instanci "$inst
    filename="thread_increase_dir/sd_min"$Process_min"max"$Process_max"inst"$inst".txt"
    touch $filename
    date +"%c"
    date +"%c" >> $filename
    echo "process time[s]" >> $filename
    for i in $(seq $Process_max -1 $Process_min);
    do   
        echo "process amount $i"
        if [[ $i -le 8 ]]
        then
            divider=1
        elif [[ $i -ge 9 ]] && [[ $i -le 16 ]]
        then
            divider=3
        elif [[ $i -ge 17 ]] && [[ $i -le 32 ]]
        then
            divider=3
        else
            divider=3
        fi
        echo "divider: $divider"
        MiddleTime=0
        for d in $(seq 1 $divider);
        do
            echo "measure $d"
            STARTTIME=$(date +%s)
            mpirun -n $i ./p3a -e "nothing" -t $i> change_threads_output.txt
            ENDTIME=$(date +%s)
            #Time=$[$ENDTIME - $STARTTIME]
            Time=$(python get_inst_time.py)
            echo "time: $Time"
            MiddleTime=$(python -c "print($MiddleTime + $Time)")
            echo "MidTime $MiddleTime"
        done
        MiddleTime=$(python -c "print($MiddleTime/$divider)")
        echo "$i $MiddleTime"
        echo "$i $MiddleTime" >> $filename
        echo "ende all measures"
    done
done
