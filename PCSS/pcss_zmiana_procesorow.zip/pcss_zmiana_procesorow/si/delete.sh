#!/bin/bash
rm example_file.txt
rm evaluator.log
rm CTestfile.cmake
rm local_search.log
rm p3arun16p.err
rm p3arun16p.out
rm p3arun2nodes.err
rm p3arun2nodes.out
rm wynik.txt
rm CTestTestfile.cmake
rm CMakeCache.txt
rm cmake_install.cmake
rm -r CMakeFiles
rm Makefile
rm -r quay_divisions
