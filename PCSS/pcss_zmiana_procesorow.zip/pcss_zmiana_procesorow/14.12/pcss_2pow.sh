#!/bin/bash

#SBATCH --job-name=sd_up_pow
#SBATCH --output=thread_increase_dir/sd_proc_2pow.out
#SBATCH --error=thread_increase_dir/sd_proc_2pow.err
#SBATCH --time=10:00:00
#SBATCH --partition=standard

module load mpich

filename="thread_increase_dir/thread_2pow.txt"

mkdir "thread_increase_dir"
touch $filename

echo "process time[s]"
echo "process time[s]" >> $filename
for p in $(seq 1 10);
do
    i=$[2**$p]
    echo "process amount $i"
    if [[ $i -ge 16 ]]
    then
        divider=10
    else
        divider=4
    fi
    echo "divider: $divider"
    MiddleTime=0
    for d in $(seq 1 $divider);
    do
        echo "measure $d"
        STARTTIME=$(date +%s)
        mpirun -n $i ./p3a > change_threads_output.txt
        ENDTIME=$(date +%s)
        Time=$[$ENDTIME - $STARTTIME]
        echo "time: $Time"
        let "MiddleTime+=Time"
    done
    let "MiddleTime=MiddleTime/divider"
    echo "$i $MiddleTime"
    echo "$i $MiddleTime" >> $filename
    echo "ende all measures"
done

echo "end all process"
