#!/bin/bash

#SBATCH --job-name=sd_inc
#SBATCH --output=thread_increase_dir/sd_inc.out
#SBATCH --error=thread_increase_dir/sd_inc.err
#SBATCH --time=1-0:00:00
#SBATCH --partition=standard
#SBATCH --ntasks=128

module load mpich

Process_min=$1
Process_max=$2

filename="thread_increase_dir/sd_"$Process_min"_"$Process_max".txt"
mkdir "thread_increase_dir"
touch $filename

echo "process time[s]"
date +"%c"
date +"%c" >> $filename
echo "process time[s]" >> $filename
for i in $(seq $Process_min $Process_max);
do
    if (( $[$Process_min%2] != $[$i%2]))
    then
        continue
    fi
    echo "process amount $i"
    if [[ $i -le 8 ]]
    then
        divider=1
    elif [[ $i -ge 9 ]] && [[ $i -le 16 ]]
    then
        divider=3
    elif [[ $i -ge 17 ]] && [[ $i -le 32 ]]
    then
        divider=5
    else
        divider=10
    fi
    echo "divider: $divider"
    MiddleTime=0
    for d in $(seq 1 $divider);
    do
        echo "measure $d"
        STARTTIME=$(date +%s)
        mpirun -n $i ./p3a > change_threads_output.txt
        ENDTIME=$(date +%s)
        #Time=$[$ENDTIME - $STARTTIME]
        Time=$(python get_inst_time.py)
        echo "time: $Time"
        MiddleTime=$(python -c "print($MiddleTime + $Time)")
        echo "MidTime $MiddleTime"
    done
    MiddleTime=$(python -c "print($MiddleTime/$divider)")
    echo "$i $MiddleTime"
    echo "$i $MiddleTime" >> $filename
    echo "ende all measures"
done

echo "end all process"


