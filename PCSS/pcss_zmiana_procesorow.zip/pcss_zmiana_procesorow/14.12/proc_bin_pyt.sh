#!/bin/bash

#SBATCH --job-name=sd_bin_pyt
#SBATCH --output=thread_increase_dir/sd_bin_pyt.out
#SBATCH --error=thread_increase_dir/sd_bin_pyt.err
#SBATCH --time=1-00:00:00
#SBATCH --partition=standard
#SBATCH --ntasks=128

module load mpich

Process_min=$1
Process_max=$2

filename="thread_increase_dir/sd_bin_pyt.txt"

mkdir "thread_increase_dir"
touch $filename

echo "process time[s]"
date +"%c"
echo "measure time: $date"
echo "measure time: $date" >> $filename
echo "process time[s]" >> $filename
for ((i=$Process_max ; i>=$Process_min; i-=2));
do
    echo "process amount $i"
    if [[ $i -le 8 ]]
    then
        divider=1
    elif [[ $i -ge 9 ]] && [[ $i -le 16 ]]
    then
        divider=3
    elif [[ $i -ge 17 ]] && [[ $i -le 32 ]]
    then
        divider=5
    else
        divider=10
    fi
    echo "divider: $divider"
    MiddleTime=0.0
    for d in $(seq 1 $divider);
    do
        echo "measure $d"
        STARTTIME=$(date +%s)
        mpiexec -n $i ./p3a > change_threads_output.txt &
        wait
        ENDTIME=$(date +%s)
        Time=$[$ENDTIME - $STARTTIME]
        #Time=$(python get_inst_time.py)
        echo "time: $Time"
        MiddleTime=$(python -c "print($MiddleTime + $Time)")
        echo "MidTime $MiddleTime"
    done
    MiddleTime=$(python -c "print($MiddleTime/$divider)")
    echo "$i $MiddleTime"
    echo "$i $MiddleTime" >> $filename
    echo "ende all measures"
done

echo "end all process"
