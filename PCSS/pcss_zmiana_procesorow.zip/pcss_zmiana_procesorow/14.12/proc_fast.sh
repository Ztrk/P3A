#!/bin/bash

#SBATCH --job-name=fast_down
#SBATCH --output=thread_increase_dir/second_proc_down.out
#SBATCH --error=thread_increase_dir/second_proc_down.err
#SBATCH --time=01:00:00
#SBATCH --partition=fast
#SBATCH --ntasks=16

module load mpich

Process_max=16

filename="thread_increase_dir/thread16nt_$Process_max.txt"

mkdir "thread_increase_dir"
touch $filename

echo "process time[s]"
echo "process time[s]" >> $filename
for i in $(seq $Process_max -1 1);
do
    echo "process amount $i"
    if [[ $i -ge 30 ]]
    then
        divider=10
    elif [[ $i -ge 20 ]] && [[ $i -le 29 ]]
    then
        divider=3
    elif [[ $i -ge 10 ]] && [[ $i -le 19 ]]
    then
        divider=3
    else
        divider=1
    fi
    echo "divider: $divider"
    MiddleTime=0
    for d in $(seq 1 $divider);
    do
        echo "measure $d"
        STARTTIME=$(date +%s)
        mpirun -n $i ./p3a > change_threads_output.txt
        ENDTIME=$(date +%s)
        Time=$[$ENDTIME - $STARTTIME]
        echo "time: $Time"
        let "MiddleTime+=Time"
    done
    let "MiddleTime=MiddleTime/divider"
    echo "$i $MiddleTime"
    echo "$i $MiddleTime" >> $filename
    echo "ende all measures"
done

echo "end all process"
