#!/bin/bash

#SBATCH --job-name=th8
#SBATCH --output=thread_increase_dir/thread_test8_15.out
#SBATCH --error=thread_increase_dir/thread_testtest8_15.err
#SBATCH --time=01:00:00
#SBATCH --partition=fast
#SBATCH --ntasks=15

module load mpich

Process_max=15
divider=5

filename="thread_increase_dir/thread16nt_$Process_max.txt"

touch $filename

echo "process time[s]"
echo "process time[s]" >> $filename
for i in $(seq 8 $Process_max);
do
    MiddleTime=0
    echo "process amount $i"
    for j in $(seq 1 $divider);
    do
        echo "measure $j"
        STARTTIME=$(date +%s)
        mpirun -n $i ./p3a > change_threads_output.txt
        ENDTIME=$(date +%s)
        Time=$[$ENDTIME - $STARTTIME]
        echo "time: $Time"
        let "MiddleTime+=Time"
    done
    let "Time=Time/divider"
    echo "$i $MiddleTime"
    echo "$i $MiddleTime" >> $filename
    echo "ende all measures"
done

echo "end all process"
