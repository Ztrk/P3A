#!/bin/bash

#SBATCH --job-name=rot
#SBATCH --output=thread_increase_dir/rot.out
#SBATCH --error=thread_increase_dir/rot.err
#SBATCH --time=5-0:00:00
#SBATCH --partition=standard
#SBATCH --ntasks=100

module load mpich

Process_min=$1
Process_max=$2
Inst_min=100


mkdir "thread_increase_dir"

filename="thread_increase_dir/rot"$Process_min"_"$Process_max".txt"
touch $filename
date +"%c"
date +"%c" >> $filename
echo "process time[s]" >> $filename
for i in $(seq $Process_max -1 $Process_min);
do  
    divider=1
    echo "process amount $i"
    if [[ $i -le 8 ]]
    then
        divider=1
    elif [[ $i -ge 9 ]] && [[ $i -le 16 ]]
    then
        divider=3
    elif [[ $i -ge 17 ]] && [[ $i -le 32 ]]
    then
        divider=5
    else
        divider=10
    fi
    echo "divider: $divider"
    MiddleTime=0
    basic=0
    for d in $(seq 1 $divider);
    do
        echo "measure $d"
        STARTTIME=$(date +%s)
        mpirun -n $i ./p3a > change_threads_output.txt
        ENDTIME=$(date +%s)
        #Time=$[$ENDTIME - $STARTTIME]
        Time=$(python get_inst_time.py)
        echo "time: $Time"
        re='^[0-9]+([.][0-9]+)?$'
        if ! [[ $Time =~ $re ]] ; then
            echo "error:Time is Not a number"
        else
            basic=$[$basic+1]
            MiddleTime=$(python -c "print($MiddleTime + $Time)")
        fi
        echo "MidTime $MiddleTime"
    done
    if (($basic == 0)); then
        basic=1
    fi
    MiddleTime=$(python -c "print($MiddleTime/$basic)")
    echo "$i $MiddleTime"
    echo "$i $MiddleTime" >> $filename
    echo "ende all measures"
done
